export { default } from "./FrequencyLab";
