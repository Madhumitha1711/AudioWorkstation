export { default } from "./LifeBeforeDawLab";
