export { default } from "./RoomTreatmentLab";
