export { default } from "./MicTypeLab";
