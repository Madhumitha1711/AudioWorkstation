export { default } from "./WhatIsInterfaceLab";
