export { default } from "./HearingAgeLab";
