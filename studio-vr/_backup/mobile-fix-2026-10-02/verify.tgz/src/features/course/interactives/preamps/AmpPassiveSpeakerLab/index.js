export { default } from "./AmpPassiveSpeakerLab";
