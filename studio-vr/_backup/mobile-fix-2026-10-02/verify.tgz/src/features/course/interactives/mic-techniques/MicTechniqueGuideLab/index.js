export { default } from "./MicTechniqueGuideLab";
