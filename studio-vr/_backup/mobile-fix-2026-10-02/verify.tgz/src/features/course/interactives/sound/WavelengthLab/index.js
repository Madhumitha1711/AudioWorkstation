export { default } from "./WavelengthLab";
