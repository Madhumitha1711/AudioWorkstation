export { default } from "./StudioTypesLab";
