export { default } from "./AmplitudeLab";
