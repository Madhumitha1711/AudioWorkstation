export { default } from "./ActiveSpeakerLab";
