export { default } from "./WhyAmplificationLab";
