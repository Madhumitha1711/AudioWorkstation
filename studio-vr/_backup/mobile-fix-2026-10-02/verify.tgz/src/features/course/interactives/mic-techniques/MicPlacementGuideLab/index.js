export { default } from "./MicPlacementGuideLab";
