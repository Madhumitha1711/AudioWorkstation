export { default } from "./StudioRoomsLab";
