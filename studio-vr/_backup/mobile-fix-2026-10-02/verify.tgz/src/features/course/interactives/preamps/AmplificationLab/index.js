export { default } from "./AmplificationLab";
