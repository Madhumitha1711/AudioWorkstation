export { default } from "./StudioAcousticsLab";
