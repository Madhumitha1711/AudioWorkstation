export { default } from "./MicPolarPatternLab";
