export { default } from "./CriticalListeningLab";
