export { default } from "./StudioHotspotsPanel";
