export { default } from "./HotspotPrecheck";
