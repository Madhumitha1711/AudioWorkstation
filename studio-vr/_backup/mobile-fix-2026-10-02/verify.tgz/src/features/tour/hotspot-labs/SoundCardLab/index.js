export { default } from "./SoundCardLab";
