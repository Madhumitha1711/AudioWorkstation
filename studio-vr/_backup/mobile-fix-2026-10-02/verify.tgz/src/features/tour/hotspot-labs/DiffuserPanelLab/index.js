export { default } from "./DiffuserPanelLab";
