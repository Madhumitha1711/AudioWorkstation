export { default } from "./SpeakerListeningLab";
