import { fmtTime } from "../lib/format";
import { DEMO_CLIPS } from "../lib/constants";
import { TrackIcon } from "./icons";
import { TrackInsertRack, TrackSendRack } from "./TrackRacks";

export function TrackList({
  tracklistRef,
  onTracklistScroll,
  trackRowRefs,
  tracks,
  selectedTrackId,
  setSelectedTrackId,
  selectedRegion,
  exitSelection,
  anySoloed,
  setTrackVolume,
  handleTrackFile,
  loadDemoForTrack,
  recordingTrackId,
  onStartRecording,
  onStopRecording,
  toggleTrackSolo,
  toggleTrackMute,
  downloadingTrackId,
  handleDownloadTrack,
  removeTrack,
  chainActions,
  sendActions,
  openAddTrackDialog,
}) {
  return (
    <div className="tracklist" ref={tracklistRef} onScroll={onTracklistScroll}>
      <div className="tracklist-head mono">TRACKS</div>
      {tracks.map((track, trackIndex) => (
        <div
          key={track.id}
          ref={(el) => {
            if (el) trackRowRefs.current.set(track.id, el);
            else trackRowRefs.current.delete(track.id);
          }}
          className={
            "track-row" +
            (track.kind === "aux" ? " is-aux" : "") +
            (track.id === selectedTrackId ? " is-selected" : "") +
            (track.solo ? " is-soloed" : "") +
            (anySoloed && !track.solo ? " is-dimmed" : "")
          }
          style={{ "--track-color": `var(--${track.color})` }}
          onClick={() => {
            setSelectedTrackId(track.id);
            if (selectedRegion && selectedRegion.trackId !== track.id) exitSelection();
          }}
        >
          <div className="track-row__head">
            <span className="track-num mono">{trackIndex + 1}</span>
            <div className="track-swatch">
              <TrackIcon ikey={track.icon} />
            </div>
            <div className="track-meta">
              <div className="track-name">{track.name}</div>
              <div className="track-sub-row">
                <div className="track-sub mono">
                  {recordingTrackId === track.id ? (
                    <span className="track-sub-recording">● Recording…</span>
                  ) : track.loadError ? (
                    <span className="track-sub-error">{track.loadError}</span>
                  ) : track.kind === "aux" ? (
                    `Aux bus · ${track.chain.length} insert${track.chain.length === 1 ? "" : "s"} · ${
                      tracks.filter((t) => (t.sends || []).some((s) => s.busId === track.id)).length
                    } send${tracks.filter((t) => (t.sends || []).some((s) => s.busId === track.id)).length === 1 ? "" : "s"} in${track.muted ? " · Muted" : ""}${track.solo ? " · Solo" : ""}`
                  ) : track.buffer ? (
                    `${track.startAt ? `@${fmtTime(track.startAt)} · ` : ""}${fmtTime(track.duration)} · ${track.chain.length} on track · ${track.regions.length} portion${track.regions.length === 1 ? "" : "s"}${(track.sends || []).length ? ` · ${track.sends.length} send${track.sends.length === 1 ? "" : "s"}` : ""}${track.muted ? " · Muted" : ""}${track.solo ? " · Solo" : ""}`
                  ) : (
                    "No audio"
                  )}
                </div>
                <input
                  type="range"
                  className="track-vol track-vol--inline"
                  min="0"
                  max="1.5"
                  step="0.01"
                  value={track.volume}
                  title="Volume"
                  onClick={(e) => e.stopPropagation()}
                  onChange={(e) => setTrackVolume(track.id, parseFloat(e.target.value))}
                />
              </div>
            </div>
          </div>
          <div className="track-row__body">
            <div className="track-row__btn-col">
              <div className="track-btns">
                {track.kind !== "aux" && (
                  <>
                    <input
                      type="file"
                      accept="audio/*"
                      id={`daw-file-${track.id}`}
                      className="daw-file-input"
                      disabled={recordingTrackId === track.id}
                      onClick={(e) => e.stopPropagation()}
                      onChange={(e) => handleTrackFile(track.id, e)}
                    />
                    <label
                      htmlFor={`daw-file-${track.id}`}
                      className={"tbtn" + (recordingTrackId === track.id ? " is-disabled" : "")}
                      title="Upload audio"
                      onClick={(e) => {
                        e.stopPropagation();
                        if (recordingTrackId === track.id) e.preventDefault();
                      }}
                    >
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M12 15V4M7.5 8.5 12 4l4.5 4.5" strokeLinecap="round" strokeLinejoin="round" />
                        <path d="M4 15v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </label>
                    <button
                      type="button"
                      className={"tbtn rec" + (recordingTrackId === track.id ? " is-recording" : "")}
                      title={
                        recordingTrackId === track.id
                          ? "Stop recording and load it onto this track"
                          : recordingTrackId
                            ? "Another track is already recording"
                            : "Record from your microphone"
                      }
                      disabled={!!recordingTrackId && recordingTrackId !== track.id}
                      onClick={(e) => {
                        e.stopPropagation();
                        if (recordingTrackId === track.id) onStopRecording();
                        else onStartRecording(track.id);
                      }}
                    >
                      {recordingTrackId === track.id ? (
                        <svg viewBox="0 0 24 24" fill="currentColor" stroke="none">
                          <rect x="7" y="7" width="10" height="10" rx="1.5" />
                        </svg>
                      ) : (
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="M12 15a3 3 0 0 0 3-3V6a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3Z" strokeLinejoin="round" />
                          <path d="M6 11a6 6 0 0 0 12 0M12 17v4M9 21h6" strokeLinecap="round" strokeLinejoin="round" />
                        </svg>
                      )}
                    </button>
                    <div className="tbtn-select-wrap" onClick={(e) => e.stopPropagation()}>
                      <span className="tbtn" aria-hidden="true">
                        D
                      </span>
                      <select
                        className="tbtn-select"
                        value=""
                        disabled={recordingTrackId === track.id}
                        title="Load a Hungarian Dance No. 5 stem onto this track"
                        aria-label="Load a demo clip onto this track"
                        onChange={(e) => {
                          const clip = DEMO_CLIPS.find((c) => c.id === e.target.value);
                          if (clip) loadDemoForTrack(track.id, clip);
                          e.target.value = "";
                        }}
                      >
                        <option value="" disabled>
                          Demo…
                        </option>
                        {DEMO_CLIPS.map((clip) => (
                          <option key={clip.id} value={clip.id}>
                            {clip.name.replace("Hungarian Dance No. 5 — ", "")}
                          </option>
                        ))}
                      </select>
                    </div>
                  </>
                )}
                <button
                  className={"tbtn s" + (track.solo ? " is-on" : "")}
                  title={track.solo ? "Unsolo track" : "Solo track — silences every other track (S)"}
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleTrackSolo(track.id);
                  }}
                >
                  S
                </button>
                <button
                  className={"tbtn m" + (track.muted ? " is-on" : "")}
                  title={track.muted ? "Unmute track" : "Mute track (M)"}
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleTrackMute(track.id);
                  }}
                >
                  M
                </button>
                <button
                  className="tbtn"
                  title={
                    track.buffer
                      ? "Download this track (its own portions + volume) as a WAV"
                      : track.kind === "aux"
                        ? "Aux buses have nothing of their own to download — download the full mix instead"
                        : "Add audio to this track first"
                  }
                  disabled={!track.buffer || downloadingTrackId === track.id}
                  onClick={(e) => {
                    e.stopPropagation();
                    void handleDownloadTrack(track.id);
                  }}
                >
                  {downloadingTrackId === track.id ? (
                    "…"
                  ) : (
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M12 4v11M7.5 11.5 12 16l4.5-4.5" strokeLinecap="round" strokeLinejoin="round" />
                      <path d="M4 17v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  )}
                </button>
                <button
                  className="tbtn danger"
                  title="Remove track"
                  onClick={(e) => {
                    e.stopPropagation();
                    removeTrack(track.id);
                  }}
                >
                  ×
                </button>
              </div>
            </div>

            <div className="track-row__racks">
              <div className="track-row__rack-row">
                <div className="track-row__rack-label mono">INS</div>
                <TrackInsertRack dense fixedSlots={5} track={track} chainActions={chainActions} />
              </div>
              <div className="track-row__rack-row">
                <div className="track-row__rack-label mono">SEND</div>
                <TrackSendRack dense fixedSlots={5} track={track} tracks={tracks} sendActions={sendActions} toggleTrackSolo={toggleTrackSolo} />
              </div>
            </div>
          </div>
        </div>
      ))}

      <div className="track-row add-track-row" onClick={openAddTrackDialog} title="New Track…">
        <span className="add-track-plus">+</span>
        <span>Add Track</span>
      </div>
    </div>
  );
}
